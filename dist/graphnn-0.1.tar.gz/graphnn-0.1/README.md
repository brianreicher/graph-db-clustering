# graph-nn
Utilizing Spark &amp; Kafka streaming to predict real-time sports betting odds with a GraphNN, build with Scala, PyTorch and Neo4j.
